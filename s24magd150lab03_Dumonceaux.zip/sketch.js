function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  let bubbles = 10;
  let stones = 15.5;
  print('Bubbles');
  
  circle(mouseX, mouseY, 30);
  text('I am your bubble screensaver :)', width / 4, height);
  text('There are ' + frameCount + ' bubbles in your computer', 50, 50);
  
  let m = max(bubbles, stones);
  let n = min(bubbles, stones - bubbles - 1);
  print(bubbles + stones);
  print(stones % bubbles);
  print(m);
  print(n);
  let x = map(3, 0, 10, 0, 50);
  print(x);
}