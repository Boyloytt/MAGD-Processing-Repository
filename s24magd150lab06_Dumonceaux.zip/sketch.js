var x, y;
function setup() {
  createCanvas(400, 400);
  x = 0;
  y = 150;
}

function draw() {
  colorMode(RGB);
  background(200, 50, 0);
  textSize(20);
  text('click left & right mouse',100,20);
  text('press any key', 145, 350);
  
 //left arm and right leg movement
  push();
  fill(0,100,255);
  if(mouseIsPressed == true && mouseButton == LEFT){
    runright();
  }
  
  rect(200,200,20,60)
  rotate(HALF_PI /20);
  rect(155, 120, 20, 50);
  pop();
  
   //right arm and left leg movement

  push();
  if(mouseIsPressed == true && mouseButton == RIGHT){
    runleft();
  }
  fill(0,100,255);
  rect(170, 200, 20, 60);
  rotate(-PI / 40);
  rect(215, 150, 20, 50);
  pop();
  
  //body
   push();
  fill(0,255,150)
  rect(165, 130, 60, 70)
  pop();
  
  //face
  
  push();
  if(keyIsPressed == true){
    bigHead();
  }
  fill(255,255,0);
  rect(175, 90, 40, 40);
  fill(0,0,0)
  rect(182,100, 5,5);
  rect(202,100, 5,5);
  rect(182, 120, 25, 5);
  rect(205,115, 5,5);
  rect(179,115, 5,5);
  
  pop();
}
//moves right leg and left arm to look like moving
function runright(){ 
  translate(-7,-1);
  rotate(-PI /70);
  
}
//moves left leg and right arm
function runleft(){
  translate(12,-12);
  rotate(HALF_PI /20);
}
//scales head 2x as big and prints text because guy is so happy!
function bigHead(){
  text('YIPPEE!', 160, 300);
  translate(-195, -120)
  scale(2);
  
}

