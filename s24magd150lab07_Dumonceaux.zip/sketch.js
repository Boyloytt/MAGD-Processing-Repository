let seed = [];
let x = [];
let y = [];
let planted = [false, false, false];
//array of flowers
function setup() {
  createCanvas(400, 400);
  for (let i = 0; i < 3; i++) {
    seed[i] = new Flower();
  }
 
}
// when mouse is pressed it plants a flower on the coursor
function mousePressed(){
  if(planted[0] == false){
    x[0] = mouseX;
    y[0] = mouseY;
      planted[0] = true;
  }
  else if(planted[1] == false){
    x[1] = mouseX;
    y[1] = mouseY;
      planted[1] = true;
  }
  else if(planted[2] == false){
    x[2] = mouseX;
    y[2] = mouseY;
      planted[2] = true;
  }
}
function draw() {
  colorMode(RGB);
  background(0, 150, 200);
  fill(0, 200, 100);
  strokeWeight(3);
  stroke(0, 180, 100);
  rect(0, 300, 400, 100);
  //checks if certain plant object in the array has already been planted
  if(planted[0] == true){
    seed[0].plant(x[0], y[0]);
  }
  if(planted[1] == true){
    seed[1].plant(x[1], y[1]);
  }
   if(planted[2] == true){
    seed[2].plant(x[2], y[2]);
  }
  
}
class Flower{
  constructor(){
    
  }
  //makes a flower image
  plant(x, y){
    push();
    translate(x, y);
    noFill();
    strokeWeight(8);
    stroke(0, 150, 100);
    bezier(0, 50, -10, 100, 30, 150, 10, 200);
    pop();
    
   push();
    fill(255,255,255);
    strokeWeight(1);
    stroke(0,0,0);
    translate(x, y);
    for(let i = 0; i < 10; i++){
    ellipse(0, -50, 40, 80);
      rotate(radians(360 /10));
    }
    pop();
    push();
    fill(255, 255, 0);
    translate(x, y);
    circle(0, 0, 50);
    pop();
  }
}