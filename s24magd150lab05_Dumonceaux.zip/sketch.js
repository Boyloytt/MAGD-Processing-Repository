var x,y, z, w;
var x1, y1, r;
var x2, y2, z2, w2;
var on, left, right, up, down;
function setup() {
  createCanvas(400, 400);
  x = 270;
  y = 320;
  w = 95;
  z = 55;
  x1 = 84;
  y1 = 348;
  r = 80;
  on = false;
  left = false;
  up = false;
  
  x2 = 100;
    y2 = 110;
    z2 = 20;
    w2 = 20;
}


function draw() {
  background(220);
  
  
  
  
  if(mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + z){
    fill(200);
  }
  else{
    fill(255);
  }
  rect(x,y,w,z);
  if(mouseIsPressed){
    if(mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + z){
    on = false;
  }
  }
  
  if(mouseX > (x1 - r/2) && mouseX < (x1 + r/2) && mouseY > (y1 - r/2) && mouseY < (y1 + r/2)){
    fill(200);
  }
  else{
    fill(255);
  }
   circle(x1, y1, r);
  if(mouseIsPressed){
    if(mouseX > (x1 - r/2) && mouseX < (x1 + r/2) && mouseY > (y1 - r/2) && mouseY < (y1 + r/2)){
      on = true;
    }
  }

  
  if(x2 > 280){
      left = true;
     }
  if(x2 < 100){
    left = false;
  }
  if(left == true){
    x2--;
  }
  else{
        x2++;
}
  if(y2 > 230){
    up = true;
  }
  if(y2 < 100){
    up = false;
  }
  if(up == true){
    y2--; 
     }
  else{
    y2++;
  }
  
  
push();
  fill(0);
  text('On', 75, 350);
  text('Off', 310, 350);
  fill(200);
  rect(100, 100, 200, 150);
  line(170, 100, 135, 50);
  line(230, 100, 270, 50);
  pop();
  
  if(on == true){
    fill(30);
    rect(x2, y2, z2, w2);
  }
  
}